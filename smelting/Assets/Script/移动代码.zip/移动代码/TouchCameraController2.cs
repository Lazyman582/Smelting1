using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.UI;

public class TouchCameraController2 : MonoBehaviour
{
    [Header("���ģʽ")]
    [SerializeField] private CameraMode cameraMode = CameraMode.Orbit;

    [Header("���������ã�Χ��Ŀ����ת��")]
    [SerializeField] private Transform orbitTarget;
    [SerializeField] private float orbitDistance = 10f;
    [SerializeField] private float orbitSpeed = 0.5f;

    [Header("����������ã�������ת��")]
    [SerializeField] private float freeRotateSpeed = 0.3f;

    [Header("ͨ������")]
    [SerializeField] private bool invertY = true;
    [SerializeField] private bool invertX = false;
    [SerializeField] private float smoothness = 5f;

    [Header("��������")]
    [SerializeField] private bool enablePinchZoom = true;
    [SerializeField] private float zoomSpeed = 0.1f;
    [SerializeField] private float minZoom = 2f;
    [SerializeField] private float maxZoom = 20f;

    [Header("������������")]
    [SerializeField] private float rightAreaStartRatio = 0.4f; // �Ҳ�������ʼλ��
    [SerializeField] private bool ignoreUIElements = true; // �Ƿ����UIԪ��
    [SerializeField] private bool debugMode = false;

    [Header("����")]
    public VirtualJoystick joystick; // ����ҡ�ˣ���ѡ��

    private enum CameraMode
    {
        Orbit,      // ��������Χ��Ŀ����ת��
        Free        // ���������������ת��
    }

    private Vector2 lastTouchPosition;
    private bool isRotating = false;
    private float currentDistance;
    private float targetXRotation;
    private float targetYRotation;
    private float currentXRotation;
    private float currentYRotation;

    // ���ڼ���Ƿ�����UI�ϵ����
    private EventSystem eventSystem;

    void Start()
    {
        // ��ȡEventSystem
        eventSystem = EventSystem.current;
        //��ȡFixed Joystick
        joystick= GameObject.Find("Canvas/joystick/Fixed Joystick").GetComponent<VirtualJoystick>();

        // ��ʼ��
        if (cameraMode == CameraMode.Orbit && orbitTarget == null)
        {
            Debug.LogWarning("δ���ù��Ŀ�꣬����һ��Ĭ��Ŀ��");
            GameObject target = new GameObject("CameraTarget");
            target.transform.position = Vector3.zero;
            orbitTarget = target.transform;
        }

        // ���ó�ʼλ�ú���ת
        if (cameraMode == CameraMode.Orbit && orbitTarget != null)
        {
            Vector3 direction = (transform.position - orbitTarget.position).normalized;
            currentDistance = Vector3.Distance(transform.position, orbitTarget.position);

            Vector3 angles = transform.eulerAngles;
            targetXRotation = angles.x;
            targetYRotation = angles.y;
        }
        else
        {
            Vector3 angles = transform.eulerAngles;
            targetXRotation = angles.x;
            targetYRotation = angles.y;
        }

        currentXRotation = targetXRotation;
        currentYRotation = targetYRotation;
        currentDistance = orbitDistance;
    }

    void Update()
    {
        // ������ת����
        HandleRotationInput();

        if (enablePinchZoom)
        {
            HandlePinchZoom();
        }

        // ƽ���������
        SmoothUpdateCamera();
    }

    // ��鴥���Ƿ���UIԪ����
    private bool IsPointerOverUIObject(Vector2 screenPosition)
    {
        if (EventSystem.current == null)
            return false;

        PointerEventData eventData = new PointerEventData(EventSystem.current);
        eventData.position = screenPosition;

        var results = new System.Collections.Generic.List<RaycastResult>();
        EventSystem.current.RaycastAll(eventData, results);

        return results.Count > 0;
    }

    // ��鴥���Ƿ���ҡ����
    private bool IsPointerOverJoystick(Vector2 screenPosition)
    {
        if (EventSystem.current == null) return false;

        PointerEventData eventData = new PointerEventData(EventSystem.current);
        eventData.position = screenPosition;

        var results = new System.Collections.Generic.List<RaycastResult>();
        EventSystem.current.RaycastAll(eventData, results);

        foreach (var result in results)
        {
            // ����Ƿ���ҡ�����
            if (result.gameObject.GetComponent<VirtualJoystick>() != null)
                return true;

            // ����Ƿ���ҡ�˵�������
            if (result.gameObject.GetComponentInParent<VirtualJoystick>() != null)
                return true;
        }

        return false;
    }

    // ����Ƿ��������������
    private bool IsInCameraControlArea(Vector2 screenPosition)
    {
        // �����UI���������˺���UI���򲻴���
        if (ignoreUIElements && IsPointerOverUIObject(screenPosition))
        {
            if (debugMode)
                Debug.Log("������UI�ϣ��������������");
            return false;
        }

        // ����Ƿ����Ҳ�����
        bool isRightArea = screenPosition.x > Screen.width * rightAreaStartRatio;

        if (debugMode && isRightArea)
            Debug.Log($"�������Ҳ�����: {screenPosition.x} > {Screen.width * rightAreaStartRatio}");

        return isRightArea;
    }

    void HandleRotationInput()
    {
        // ��ָ��ת
        if (Input.touchCount == 1)
        {
            Touch touch = Input.GetTouch(0);
            Vector2 screenPos = touch.position;
            if (screenPos.x > Screen.width / 4)
            {
                switch (touch.phase)
                {
                    case TouchPhase.Began:
                        lastTouchPosition = touch.position;
                        isRotating = true;
                        if (debugMode) Debug.Log("��ʼ��ת");
                        break;

                    case TouchPhase.Moved:
                        if (isRotating)
                        {
                            Vector2 touchDelta = touch.position - lastTouchPosition;

                            // ������ת����
                            float rotX = touchDelta.y * (cameraMode == CameraMode.Orbit ? orbitSpeed : freeRotateSpeed) * (invertY ? -1 : 1);
                            float rotY = touchDelta.x * (cameraMode == CameraMode.Orbit ? orbitSpeed : freeRotateSpeed) * (invertX ? 1 : -1);

                            // ����Ŀ����ת
                            targetXRotation += rotX;
                            targetYRotation += rotY;

                            // ���ƴ�ֱ��ת�Ƕ�
                            targetXRotation = Mathf.Clamp(targetXRotation, -80f, 80f);

                            lastTouchPosition = touch.position;

                            if (debugMode)
                                Debug.Log($"��ת��: rotX={rotX}, rotY={rotY}, targetXRotation={targetXRotation}");
                        }
                        break;

                    case TouchPhase.Ended:
                    case TouchPhase.Canceled:
                        isRotating = false;
                        if (debugMode) Debug.Log("������ת");
                        break;
                }
            }

        }
        else if (Input.touchCount > 1)
        {
            Touch touch1 = Input.GetTouch(0);
            Touch touch2 = Input.GetTouch(1);
            Vector2 screenPos1 = touch1.position;
            Vector2 screenPos2 = touch2.position;
          
            // ��㴥��ʱ��ͣ��ת
            isRotating = false;
        }
    }

    void HandlePinchZoom()
    {
        if (Input.touchCount == 2)
        {
            Touch touch1 = Input.GetTouch(0);
            Touch touch2 = Input.GetTouch(1);
            Vector2 screenPos1 = touch1.position;
            Vector2 screenPos2 = touch2.position;

            // ��������������Ƿ��������������
            if (IsInCameraControlArea(screenPos1) && IsInCameraControlArea(screenPos2))
            {
                // ��ȡǰһ֡���������
                Vector2 prevPos1 = touch1.position - touch1.deltaPosition;
                Vector2 prevPos2 = touch2.position - touch2.deltaPosition;
                float prevDistance = Vector2.Distance(prevPos1, prevPos2);

                // ��ȡ��ǰ֡���������
                float currentDistance = Vector2.Distance(touch1.position, touch2.position);

                // �������仯
                float deltaDistance = currentDistance - prevDistance;

                // Ӧ������
                if (cameraMode == CameraMode.Orbit && orbitTarget != null)
                {
                    orbitDistance -= deltaDistance * zoomSpeed;
                    orbitDistance = Mathf.Clamp(orbitDistance, minZoom, maxZoom);

                    if (debugMode)
                        Debug.Log($"����: delta={deltaDistance}, orbitDistance={orbitDistance}");
                }
                else
                {
                    // �������ģʽ������
                    transform.Translate(Vector3.forward * deltaDistance * zoomSpeed, Space.Self);
                }
            }
        }
    }

    void SmoothUpdateCamera()
    {
        // ƽ����ֵ��ת
        currentXRotation = Mathf.Lerp(currentXRotation, targetXRotation, Time.deltaTime * smoothness);
        currentYRotation = Mathf.Lerp(currentYRotation, targetYRotation, Time.deltaTime * smoothness);

        if (cameraMode == CameraMode.Orbit && orbitTarget != null)
        {
            // ������ģʽ
            Quaternion rotation = Quaternion.Euler(currentXRotation, currentYRotation, 0);

            // �������λ�ã�Χ��Ŀ�꣩
            Vector3 desiredPosition = orbitTarget.position + rotation * (Vector3.back * orbitDistance);

            // �������λ�ú���ת
            transform.position = desiredPosition;
            transform.LookAt(orbitTarget);
        }
        else
        {
            // �������ģʽ
            transform.rotation = Quaternion.Euler(currentXRotation, currentYRotation, 0);
        }
    }

    // �������������ù��Ŀ��
    public void SetOrbitTarget(Transform newTarget)
    {
        orbitTarget = newTarget;
        if (orbitTarget != null)
        {
            Vector3 directionToTarget = orbitTarget.position - transform.position;
            Quaternion lookRotation = Quaternion.LookRotation(directionToTarget);
            Vector3 angles = lookRotation.eulerAngles;
            targetXRotation = angles.x;
            targetYRotation = angles.y;

            orbitDistance = directionToTarget.magnitude;
        }
    }
}